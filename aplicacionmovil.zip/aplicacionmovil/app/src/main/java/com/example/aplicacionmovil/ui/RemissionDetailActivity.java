package com.example.aplicacionmovil.ui;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.aplicacionmovil.R;
import com.example.aplicacionmovil.model.DBHelper;

public class RemissionDetailActivity extends AppCompatActivity {

    private TextView tvTitle, tvDescription;
    private Button btnEdit, btnDelete;
    private DBHelper dbHelper;
    private int remissionId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remission_detail);

        // Inicializa las vistas
        tvTitle = findViewById(R.id.tvRemissionTitle);
        tvDescription = findViewById(R.id.tvRemissionDescription);
        btnEdit = findViewById(R.id.btnEdit);
        btnDelete = findViewById(R.id.btnDelete);

        // Inicializa el DBHelper
        dbHelper = new DBHelper(this);

        // Obtiene el ID de la remisión que se envía desde otra actividad
        // Ejemplo: intent.putExtra("remission_id", 5);
        remissionId = getIntent().getIntExtra("remission_id", -1);

        // Carga los datos de la remisión si el ID es válido
        if (remissionId != -1) {
            loadRemissionDetails(remissionId);
        } else {
            Toast.makeText(this, "No se recibió una remisión válida", Toast.LENGTH_SHORT).show();
            finish(); // Cierra la actividad si no hay ID
        }

        // Botón para editar la remisión (opcional)
        btnEdit.setOnClickListener(v -> {
            // Aquí podrías abrir otra actividad para editar
            // la remisión, o mostrar un diálogo. Por ejemplo:
            // Intent intent = new Intent(this, EditRemissionActivity.class);
            // intent.putExtra("remission_id", remissionId);
            // startActivity(intent);
            Toast.makeText(this, "Funcionalidad de edición pendiente", Toast.LENGTH_SHORT).show();
        });

        // Botón para eliminar la remisión
        btnDelete.setOnClickListener(v -> {
            boolean deleted = dbHelper.deleteRemission(remissionId);
            if (deleted) {
                Toast.makeText(this, "Remisión eliminada", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Error al eliminar la remisión", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     * Carga los datos de la remisión desde la base de datos
     * y los muestra en los TextViews.
     *
     * @param remissionId ID de la remisión.
     */
    private void loadRemissionDetails(int remissionId) {
        Cursor cursor = dbHelper.getRemissionById(remissionId);
        if (cursor != null && cursor.moveToFirst()) {
            // Ajusta los nombres de columna a los definidos en DBHelper
            String title = cursor.getString(cursor.getColumnIndexOrThrow("title"));
            String description = cursor.getString(cursor.getColumnIndexOrThrow("description"));

            // Muestra la información en pantalla
            tvTitle.setText(title);
            tvDescription.setText(description);

            cursor.close();
        } else {
            Toast.makeText(this, "No se encontró la remisión", Toast.LENGTH_SHORT).show();
        }
    }
}
