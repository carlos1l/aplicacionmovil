package com.example.aplicacionmovil.entities;

public class Remission {
    private int id;
    private String code;   // Código
    private String value;  // Valor

    public Remission() {
    }

    // Constructor para cuando ya tenemos ID
    public Remission(int id, String code, String value) {
        this.id = id;
        this.code = code;
        this.value = value;
    }

    // Constructor sin ID (al insertar en la BD)
    public Remission(String code, String value) {
        this.code = code;
        this.value = value;
    }

    // Getters & Setters
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }
    public void setCode(String code) {
        this.code = code;
    }

    public String getValue() {
        return value;
    }
    public void setValue(String value) {
        this.value = value;
    }
}
