package com.example.aplicacionmovil.entities;

public class User {
}
